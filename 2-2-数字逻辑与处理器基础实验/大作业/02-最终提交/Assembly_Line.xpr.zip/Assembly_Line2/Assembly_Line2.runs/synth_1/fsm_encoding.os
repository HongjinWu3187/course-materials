
 add_fsm_encoding \
       {UartTx.state} \
       { }  \
       {{000 00} {001 01} {010 10} {011 11} }

 add_fsm_encoding \
       {UartRx.state} \
       { }  \
       {{000 00} {001 01} {010 10} {011 11} }
